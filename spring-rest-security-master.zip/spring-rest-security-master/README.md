# spring-security example for authorization of REST urls
<b> Authrization of REST-API using spring security </b>
This project helps to verify the user access also known as Authorization-Scenario. Whenever user is trying to access the end-points 
we need to prevent him when he is trying to access the proteced resource.

In this example, 

    User passes Authorization token with header of http request.
    Based on the token, identifying the user.
    Checking the authorization for this user. If user is authorized execute the code or else send the unauthorized access.

These are the most common scenarios while developing any rest application. Spring security is the best for doing this job because 
it has already provides this machanisam.





